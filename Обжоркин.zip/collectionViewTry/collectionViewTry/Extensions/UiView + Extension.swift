//
//  UiView + Extension.swift
//  collectionViewTry
//
//  Created by Антон on 02.11.2022.
//

import Foundation
import UIKit

extension UIView {
    @IBInspectable var cornerRadius:CGFloat {
        get{
            return self.cornerRadius
        }
        set{
            self.layer.cornerRadius = newValue
        }
    }
}
