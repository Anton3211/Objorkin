//
//  String+Extension.swift
//  collectionViewTry
//
//  Created by Антон on 04.11.2022.
//

import Foundation


extension String {
    var asUrl:URL? {
        return URL(string: self)
    }
}
