//
//  UserDefaults + Extansion.swift
//  Обжоркин
//
//  Created by Антон on 12.11.2022.
//

import Foundation


extension UserDefaults {
    
    private enum UserDeafaultsKeys:String {
        case hasOnboarded
    }
    var hasOnboarded:Bool {
        get {
            bool(forKey: UserDeafaultsKeys.hasOnboarded.rawValue)
        }
        
        set{
            setValue(newValue, forKey: UserDeafaultsKeys.hasOnboarded.rawValue)
        }
    }
    
}
