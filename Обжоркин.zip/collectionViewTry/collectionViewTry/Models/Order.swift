//
//  Order.swift
//  collectionViewTry
//
//  Created by Антон on 08.11.2022.
//

import Foundation


struct Order: Decodable {
    let id: String?
    let name: String?
    let dish: Dish?
}
