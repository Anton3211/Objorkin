//
//  AllDishes.swift
//  collectionViewTry
//
//  Created by Антон on 08.11.2022.
//

import Foundation

struct AllDishes:Decodable {
    let categories:[DishCategory]?
    let populars:[Dish]?
    let specials:[Dish]?
}
