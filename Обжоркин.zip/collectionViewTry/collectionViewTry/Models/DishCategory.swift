//
//  DishCategory.swift
//  collectionViewTry
//
//  Created by Антон on 04.11.2022.
//

import Foundation


struct DishCategory:Decodable {
    let id,name,image:String?
    
    enum CodingKeys:String, CodingKey {
        case id
        case name = "title"
        case image
    }
}
