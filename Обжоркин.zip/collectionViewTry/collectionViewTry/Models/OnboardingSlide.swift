//
//  OnboardingSlide.swift
//  collectionViewTry
//
//  Created by Антон on 02.11.2022.
//

import UIKit

struct OnboardingSlide {
    var title:String
    var description:String
    var image:UIImage
}
