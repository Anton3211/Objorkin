//
//  Dish.swift
//  collectionViewTry
//
//  Created by Антон on 04.11.2022.
//

import Foundation


struct Dish:Decodable {
    let id,name,image,description:String?
    let calories:Double?
    
    var formattedCalories:String{
        //%.2f - два знака после токи в обозначении калорий
        return String(format: "%.2f calories", calories ?? 0)
    }
}
