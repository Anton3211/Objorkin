//
//  CardView.swift
//  collectionViewTry
//
//  Created by Антон on 04.11.2022.
//

import UIKit

class CardView: UIView {

    override init(frame: CGRect) {
        super.init(frame: frame)
        initialSetup()
    }
   
    required init?(coder:NSCoder) {
        super.init(coder: coder)
        initialSetup()
    }
    
    func initialSetup() {
        layer.shadowColor = UIColor.black.cgColor
        layer.shadowOffset = CGSize(width: 3, height: 4)
        layer.cornerRadius = 10
        layer.shadowOpacity = 0.1
        cornerRadius = 10
        layer.borderWidth = 0.1
        
    }
}
