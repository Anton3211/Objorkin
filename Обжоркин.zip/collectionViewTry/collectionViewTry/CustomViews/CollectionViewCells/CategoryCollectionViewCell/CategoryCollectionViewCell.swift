//
//  CategoryCollectionViewCell.swift
//  collectionViewTry
//
//  Created by Антон on 04.11.2022.
//

import UIKit
import Kingfisher

class CategoryCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var categoryImageView: UIImageView!
    @IBOutlet weak var categoryTatileLbl: UILabel!
    
    static let identifier = String(describing:CategoryCollectionViewCell.self)
  
    func setup(category:DishCategory) {
        categoryTatileLbl.text = category.name
        categoryImageView.kf.setImage(with: category.image?.asUrl)
        
    }
}
