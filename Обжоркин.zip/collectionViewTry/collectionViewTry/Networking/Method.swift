//
//  Method.swift
//  collectionViewTry
//
//  Created by Антон on 08.11.2022.
//

import Foundation


enum Method: String {
    case get = "GET"
    case post = "POST"
    case delete = "DELETE"
    case patch = "PATCH"
}
