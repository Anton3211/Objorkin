//
//  DishDetailViewController.swift
//  collectionViewTry
//
//  Created by Антон on 04.11.2022.
//

import UIKit
import ProgressHUD

class DishDetailViewController: UIViewController {

    @IBOutlet weak var dishImage: UIImageView!
    
    @IBOutlet weak var titleLbl: UILabel!
    
    @IBOutlet weak var categoriesLbl: UILabel!
    
    @IBOutlet weak var descriptionLbl: UILabel!
    
    @IBOutlet weak var nameField: UITextField!
    
    var dish:Dish!
    
    var arrayOfQuotas:[String] = ["Пожалуйста введите ваше имя ☺️", "Нет имени - нет заказа, прости 😢","Будет имя - будет заказ 😎","Либо говори имя, либо проваливай 🥸"]
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
       

       populateView()
        
    }
    
    private func populateView() {
        dishImage.kf.setImage(with: dish.image?.asUrl)
        titleLbl.text = dish.name
        categoriesLbl.text = dish.formattedCalories
        descriptionLbl.text = dish.description
    }
    

    @IBAction func placeOrderBtnPressd(_ sender: UIButton) {
        guard let name = nameField.text?.trimmingCharacters(in: .whitespaces),
              !name.isEmpty else {
            ProgressHUD.showError(arrayOfQuotas.randomElement())
            return
        }
        ProgressHUD.show("Размещаем ваш заказ...")
        NetworkService.shared.placeOrder(dishId: dish.id ?? "", name: name) { (result) in
            switch result {
            case .success(_):
                ProgressHUD.showSuccess("\(name), Ваш заказ принят.👨🏼‍🍳")
            case .failure(let error):
                ProgressHUD.showError(error.localizedDescription)
            }
        }
    }
    

}
