//
//  OnboardingViewController.swift
//  collectionViewTry
//
//  Created by Антон on 02.11.2022.
//

import UIKit

class OnboardingViewController: UIViewController {
    
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var pageControl: UIPageControl!
    @IBOutlet weak var myBtn: UIButton!
    
    var slideArray:[OnboardingSlide] = []
    
    var currentPage = 0 {
        didSet {
            pageControl.currentPage = currentPage
            if currentPage == slideArray.count - 1 {
                myBtn.setTitle("Начнем!", for: .normal)
            } else {
                myBtn.setTitle("Далее", for: .normal)
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        slideArray = [OnboardingSlide(title: "Быстрая доставка по городу до двери", description: "Доставка до дома и онлайн резервация заказа, так же доступен предзаказ", image:UIImage(named:"доставка")!),
                      OnboardingSlide(title: "Всегда свежая и вкусная", description: "Хранение при условии соблюдения всех норм - залог свежести", image:UIImage(named:"свежаяЕда")!),
                      OnboardingSlide(title: "Проверенные фермеры, которым мы доверяем", description: "Наши продукты только из качественного мяса", image: UIImage(named: "здороваяЕда")!)
        ]
        pageControl.numberOfPages = slideArray.count
        
    }


    @IBAction func BtnPressed(_ sender: UIButton) {
        if currentPage == slideArray.count - 1{
            let controller = storyboard?.instantiateViewController(withIdentifier: "HomeNC") as! UINavigationController
            controller.modalPresentationStyle = .fullScreen
            controller.modalTransitionStyle = .flipHorizontal
            UserDefaults.standard.hasOnboarded = true
            present(controller, animated: true)
        }else {
            currentPage += 1
            let indexPath = IndexPath(item: currentPage, section: 0)
            collectionView.scrollToItem(at: indexPath, at: .centeredHorizontally, animated: true)
        }
    }
}

extension OnboardingViewController:UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return slideArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: OnboardingCollectionViewCell.identifier, for: indexPath) as! OnboardingCollectionViewCell
        cell.setup(slideArray[indexPath.row])
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.frame.width, height: collectionView.frame.height)
    }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        let width = scrollView.frame.width
        currentPage = Int(scrollView.contentOffset.x / width)
        pageControl.currentPage = currentPage
    }
    
    
}
